/*
    FreeRTOS V6.1.1 - Copyright (C) 2011 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public
    License and the FreeRTOS license exception along with FreeRTOS; if not it
    can be viewed here: http://www.freertos.org/a00114.html and also obtained
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
/* FreeRTOS.org includes. */
#include "FreeRTOS.h"
#include "task.h"

/* Demo includes. */
#include "basic_io.h"

// CodeRed - added NXP LPC register definitions header
#include "LPC17xx.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_adc.h"
#include "lpc17xx_timer.h"

#include "light.h"
#include "oled.h"
#include "acc.h"
#include "joystick.h"
#include "rotary.h"

#include "semphr.h"

#include "webside.h"
#include "easyweb.h"
#include "ethmac.h"
#define extern
#include "tcpip.h"
#undef extern

/* Used as a loop counter to create a very crude delay. */
#define mainDELAY_LOOP_COUNT		( 0xfffff )

const portTickType xDelay100ms = 100 / portTICK_RATE_MS;
// CodeRed - added for use in dynamic side of web page
unsigned int aaPagecounter = 0;
unsigned int adcValue = 0;
static uint8_t buf[10];
// Global variables
uint32_t lux = 0;
int32_t xoff = 0;
int32_t yoff = 0;
int32_t zoff = 0;

int8_t x = 0;
int8_t y = 0;
int8_t z = 0;

uint8_t joy = -2;
uint8_t lastJoy = -2;
uint8_t rotation = -2;
uint8_t lastRotation = -2;

oled_color_t backgroundColor = OLED_COLOR_BLACK;
oled_color_t textColor = OLED_COLOR_WHITE;

// Tasks
void timerTask (void *pvParameters);
void mainTask( void *pvParameters );
void accTask( void *pvParameters );
void lightTask( void *pvParameters );
void vEasywebTask( void *pvParameters );

// Handlers
xTaskHandle lightTaskHandle;
xTaskHandle accTaskHandle;

/*-----------------------------------------------------------*/

static void intToString(int value, uint8_t* pBuf, uint32_t len, uint32_t base) {
	static const char* pAscii = "0123456789abcdefghijklmnopqrstuvwxyz";
	int pos = 0;
	int tmpValue = value;

	// the buffer must not be null and at least have a length of 2 to handle one
	// digit and null-terminator
	if (pBuf == NULL || len < 2) {
		return;
	}

	// a valid base cannot be less than 2 or larger than 36
	// a base value of 2 means binary representation. A value of 1 would mean only zeros
	// a base larger than 36 can only be used if a larger alphabet were used.
	if (base < 2 || base > 36) {
		return;
	}

	// negative value
	if (value < 0) {
		tmpValue = -tmpValue;
		value = -value;
		pBuf[pos++] = '-';
	}

	// calculate the required length of the buffer
	do {
		pos++;
		tmpValue /= base;
	} while (tmpValue > 0);

	if (pos > len) {
		// the len parameter is invalid.
		return;
	}

	pBuf[pos] = '\0';

	do {
		pBuf[--pos] = pAscii[value % base];
		value /= base;
	} while (value > 0);

	return;

}

static void init_ssp(void) {
	SSP_CFG_Type SSP_ConfigStruct;
	PINSEL_CFG_Type PinCfg;

	/*
	 * Initialize SPI pin connect
	 * P0.7 - SCK;
	 * P0.8 - MISO
	 * P0.9 - MOSI
	 * P2.2 - SSEL - used as GPIO
	 */
	PinCfg.Funcnum = 2;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 7;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 8;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 9;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 2;
	PINSEL_ConfigPin(&PinCfg);

	SSP_ConfigStructInit(&SSP_ConfigStruct);

	// Initialize SSP peripheral with parameter given in structure above
	SSP_Init(LPC_SSP1, &SSP_ConfigStruct);

	// Enable SSP peripheral
	SSP_Cmd(LPC_SSP1, ENABLE);

}

static void init_i2c(void) {
	PINSEL_CFG_Type PinCfg;

	/* Initialize I2C2 pin connect */
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 10;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 11;
	PINSEL_ConfigPin(&PinCfg);

	// Initialize I2C peripheral
	I2C_Init(LPC_I2C2, 100000);

	/* Enable I2C1 operation */
	I2C_Cmd(LPC_I2C2, ENABLE);
}

void drawDisplay(uint8_t* text, uint32_t value, oled_color_t backgroundColor, oled_color_t textColor, uint8_t line) {
	uint8_t xPos = 1 + (8 * (line - 1));
	uint8_t yPos = 8 * line;
	/* showing text */
	oled_putString(1, xPos, text, backgroundColor, textColor);
	/* output values to OLED display */
	if(value != 0) {
		intToString(value, buf, 10, 10);
		oled_fillRect((1 + 9 * 6), xPos, 80, yPos, textColor);
		oled_putString((1 + 9 * 6), xPos, buf, backgroundColor, textColor);
	}
}

void showWelcomeScreen(oled_color_t backgroundColor, oled_color_t textColor) {
	oled_clearScreen(backgroundColor);
	drawDisplay("SystemAtic", 0, backgroundColor, textColor, 1);
	drawDisplay("EC 020 - P9", 0, backgroundColor, textColor, 2);
}

void invertDispalyColor() {
	oled_color_t temp = backgroundColor;
	backgroundColor = textColor;
	textColor = temp;
	oled_clearScreen(backgroundColor);
}

void initialize() {
	init_i2c();
	init_ssp();

	oled_init();
	joystick_init();
	rotary_init();

	acc_init();
	light_init();

	acc_read(&x, &y, &z);
	xoff = 0-x;
	yoff = 0-y;
	zoff = 64-z;

	light_enable();
	light_setRange(LIGHT_RANGE_4000);

	oled_clearScreen(backgroundColor);
	showWelcomeScreen(backgroundColor, textColor);
}

void createTasks() {
	xTaskCreate( mainTask, "main Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL );
	xTaskCreate( timerTask, "time Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL );
	xTaskCreate( accTask, "Acc Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
	xTaskCreate( lightTask, "Light Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL );
	xTaskCreate( vEasywebTask, "Http Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL );
	vTaskStartScheduler();
}

int main(void) {
	initialize();
	createTasks();
	printf("STACKOVERFLOW");
    /* If all is well we will never reach here as the scheduler will now be
    running the tasks.  If we do reach here then it is likely that there was
    insufficient heap memory available for a resource to be created. */
	for( ;; );
	return 0;
}

void timerTask( void *pvParameters ) {
	for( ;; )
		{
			TCPClockHandler();
			vTaskDelay(210 / portTICK_RATE_MS);
		}
}

void mainTask( void *pvParameters )
{
	for( ;; )
	{
		printf("Main task is running\n");
		/* Joystick */
		joy = joystick_read();
		/* Rotary switch */
		rotation = rotary_read();

		if (rotation != lastRotation && rotation != ROTARY_WAIT) {
			oled_color_t temp = backgroundColor;
			backgroundColor = textColor;
			textColor = temp;
			lastRotation = rotation;
			oled_clearScreen(backgroundColor);
		}

		if (((joy & JOYSTICK_LEFT) != 0) && lastJoy != JOYSTICK_LEFT) {
			// acc task
			printf("Changing sides\n");
			oled_clearScreen(backgroundColor);
			lastJoy = JOYSTICK_LEFT;
		}

		if (((joy & JOYSTICK_RIGHT) != 0) && lastJoy != JOYSTICK_RIGHT) {
			// light task
			printf("Changing sides\n");
			oled_clearScreen(backgroundColor);
			lastJoy = JOYSTICK_RIGHT;
		}

		vTaskDelay(xDelay100ms);
	}
}

void accTask ( void *pvParameters ) {
	for( ;; )
	{
		/* Accelerometer */
		acc_read(&x, &y, &z);
		x = x+xoff;
		y = y+yoff;
		z = z+zoff;
		if(lastJoy == JOYSTICK_LEFT) {
			printf( "Acc task is running\n" );
			/* Showing values */
			drawDisplay("X Pos: ", x, backgroundColor, textColor, 1);
			drawDisplay("Y Pos: ", y, backgroundColor, textColor, 2);
			drawDisplay("Z Pos: ", z, backgroundColor, textColor, 3);
		}
		vTaskDelay(xDelay100ms);
	}
}

void lightTask ( void *pvParameters ) {
	for( ;; )
	{
		/* light */
		lux = light_read();
		if(lastJoy == JOYSTICK_RIGHT) {
			printf( "Light task is running\n" );
			/* Showing values */
			drawDisplay("Light: ", lux, backgroundColor, textColor, 1);
		}
		vTaskDelay(xDelay100ms);
	}
}

void vEasywebTask(void *pvParameters)
{
    (void)pvParameters;

    // Initialize
    TCPLowLevelInit();

    // clear HTTP-server's flag register
    HTTPStatus = 0;
    // set port we want to listen to
    TCPLocalPort = TCP_PORT_HTTP;

    // repeat forever
    while (1)
    {
        // listen for incoming TCP-connection
        if (!(SocketStatus & SOCK_ACTIVE)) TCPPassiveOpen();
        // handle network and easyWEB-stack
        DoNetworkStuff();
        // events
        HTTPServer();

        vTaskDelay(xDelay100ms);
    }
}

// This function implements a very simple dynamic HTTP-server.
// It waits until connected, then sends a HTTP-header and the
// HTML-code stored in memory. Before sending, it replaces
// some special strings with dynamic values.
// NOTE: For strings crossing page boundaries, replacing will
// not work. In this case, simply add some extra lines
// (e.g. CR and LFs) to the HTML-code.
void HTTPServer(void) {
	if (SocketStatus & SOCK_CONNECTED) // check if somebody has connected to our TCP
	{
		if (SocketStatus & SOCK_DATA_AVAILABLE) // check if remote TCP sent data
			TCPReleaseRxBuffer();                      // and throw it away

		if (SocketStatus & SOCK_TX_BUF_RELEASED) // check if buffer is free for TX
		{
			if (!(HTTPStatus & HTTP_SEND_PAGE)) // init byte-counter and pointer to webside
			{                                          // if called the 1st time
				HTTPBytesToSend = sizeof(WebSide) - 1; // get HTML length, ignore trailing zero
				PWebSide = (unsigned char *) WebSide;    // pointer to HTML-code
			}

			if (HTTPBytesToSend > MAX_TCP_TX_DATA_SIZE) // transmit a segment of MAX_SIZE
			{
				if (!(HTTPStatus & HTTP_SEND_PAGE)) // 1st time, include HTTP-header
				{
					memcpy(TCP_TX_BUF, GetResponse, sizeof(GetResponse) - 1);
					memcpy(TCP_TX_BUF + sizeof(GetResponse) - 1, PWebSide,
							MAX_TCP_TX_DATA_SIZE - sizeof(GetResponse) + 1);
					HTTPBytesToSend -= MAX_TCP_TX_DATA_SIZE
							- sizeof(GetResponse) + 1;
					PWebSide += MAX_TCP_TX_DATA_SIZE - sizeof(GetResponse) + 1;
				} else {
					memcpy(TCP_TX_BUF, PWebSide, MAX_TCP_TX_DATA_SIZE);
					HTTPBytesToSend -= MAX_TCP_TX_DATA_SIZE;
					PWebSide += MAX_TCP_TX_DATA_SIZE;
				}

				TCPTxDataCount = MAX_TCP_TX_DATA_SIZE;   // bytes to xfer
				InsertDynamicValues();               // exchange some strings...
				TCPTransmitTxBuffer();                   // xfer buffer
			} else if (HTTPBytesToSend)               // transmit leftover bytes
			{
				memcpy(TCP_TX_BUF, PWebSide, HTTPBytesToSend);
				TCPTxDataCount = HTTPBytesToSend;        // bytes to xfer
				InsertDynamicValues();               // exchange some strings...
				TCPTransmitTxBuffer();                   // send last segment
				TCPClose();                              // and close connection
				HTTPBytesToSend = 0;                     // all data sent
			}

			HTTPStatus |= HTTP_SEND_PAGE;              // ok, 1st loop executed
		}
	} else
		HTTPStatus &= ~HTTP_SEND_PAGE;       // reset help-flag if not connected
}

// Code Red - GetAD7Val function replaced
// Rather than using the AD convertor, in this version we simply increment
// a counter the function is called, wrapping at 1024.
volatile unsigned int aaScrollbar = 400;
unsigned int GetAD7Val(void) {
	aaScrollbar = (aaScrollbar + 16) % 1024;
	adcValue = (aaScrollbar / 10) * 1000 / 1024;
	return aaScrollbar;
}

// searches the TX-buffer for special strings and replaces them
// with dynamic values (AD-converter results)
// Code Red - new version of InsertDynamicValues()
void InsertDynamicValues(void) {
	unsigned char *Key;
	char NewKey[6];
	unsigned int i;

	if (TCPTxDataCount < 4)
		return;                     // there can't be any special string

	Key = TCP_TX_BUF;

	for (i = 0; i < (TCPTxDataCount - 3); i++) {
		if (*Key == 'A')
			if (*(Key + 1) == 'D')
				if (*(Key + 3) == '%')
					switch (*(Key + 2)) {
					case '1':                                 // "AD8%"?
					{
						sprintf(NewKey, "%04d", lux); // insert pseudo-ADconverter value
						memcpy(Key, NewKey, 4);
						break;
					}
					case '2':                                 // "AD7%"?
					{
						sprintf(NewKey, "%04d", x); // copy saved value from previous read
						memcpy(Key, NewKey, 3);
						break;
					}
					case '3':                                 // "AD1%"?
					{
						sprintf(NewKey, "%04d", y); // increment and insert page counter
						memcpy(Key, NewKey, 4);
						break;
					}
					case '4':                                 // "AD1%"?
					{
						sprintf(NewKey, "%04d", z); // increment and insert page counter
						memcpy(Key, NewKey, 4);
						break;
					}
				}
		Key++;
	}
}


/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* This function will only be called if an API call to create a task, queue
	or semaphore fails because there is too little heap RAM remaining. */
	printf("MallocFailed");
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed char *pcTaskName )
{
	/* This function will only be called if a task overflows its stack.  Note
	that stack overflow checking does slow down the context switch
	implementation. */
	printf("StackOverflow");
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
	/* This example does not use the idle hook to perform any processing. */
}
/*-----------------------------------------------------------*/

void vApplicationTickHook( void )
{
	/* This example does not use the tick hook to perform any processing. */
}


